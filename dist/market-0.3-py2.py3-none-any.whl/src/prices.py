def name(str):
    return str

def price(num):
    return num

def discount(num):
    return num

def finalSum(num):
    return num